function change() // no ';' here
{
    var elem = document.getElementById("myButton1");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

function change1() // no ';' here
{
    var elem = document.getElementById("myButton2");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

function change2() // no ';' here
{
    var elem = document.getElementById("myButton3");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

function change3() // no ';' here
{
    var elem = document.getElementById("myButton4");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

function change4() // no ';' here
{
    var elem = document.getElementById("myButton5");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

function change5() // no ';' here
{
    var elem = document.getElementById("myButton6");
    if (elem.value=="Subscribed") elem.value = "Subscribe";
    else elem.value = "Subscribed";
};

