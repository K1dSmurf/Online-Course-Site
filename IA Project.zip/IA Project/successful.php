<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm</title>
    <link rel="stylesheet" href="CSS/search.css">
<link rel="stylesheet" href="CSS/style.css">
<style>

</style>
</head>
<body>
<br><br><br><br><br><br><br><br><br><br>
    <center><h1>Trasaction complete</h1></center>
    <h2><a href= "Index.php">Click here to Home! </a> <h2>
</body>
</html>