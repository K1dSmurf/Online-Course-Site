<?php
session_start();//strarts session

    
    //variables used in the PHP
    $username = "";
    $password = "";

    $id ="";
    //Cookie Creation
    setcookie("id", $id, time()+(86400*30),"/");
  //Database
 $conn = new mysqli('localhost', 'root', '', 'iaproject') or die($conn->connect_error);

	if(isset($_POST['submit'])){
		

		$_SESSION['name'] = htmlentities($_POST['name']);
		$_SESSION['password'] = htmlentities($_POST['password']);

		$name = $_POST['name'];
		$password = $_POST['password'];
		

		$sql = "SELECT * FROM users WHERE username = ? AND password = ?";
		$stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $name, $password);
        $stmt->execute();
        $result = $stmt->get_result();
		$row = $result->fetch_assoc();
		 

		if ($result->num_rows == 1) {

      header('Location:Index.php');
		}
		else{
			echo "Incorrect Credentials";
		}

		$stmt->close();
		$conn->close();
	}
  
  //function to set the length
    $passwordlength= strlen($password);

    //my cookie
    setcookie("CarCookie", "UserInfo", time() + 2 * 24 * 60 * 60);



//if statement that will detemine of the form can be submitted 
    if(isset($_POST['submit'])){

        if (empty($_POST["name"])){

            $username = "*Please enter username";
        }
            
        if (empty($_POST["password"])){

        $password = "*Please enter password";
    }
    if ($passwordlength < 8){
      $password= "<br><redtext> Invalid password. Password must be at least 8 characters</redtext>";
    }
    }
   
   

    $num =$_POST
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->

	</div>

<br><br><br>
  <form method="POST" action ="<?php echo htmlentities($_SERVER['PHP_SELF']);?>"id="login-form">
    <div class ="form-group row">
    <p>
      <!-- <div class ="col-md-4"> -->
      <input type="text" id="name" class="form-control" name="name" placeholder="Username"><br/><br/>
      <span class="help-block text-danger"><?php echo $username; ?></span>
      </p>
    <p>
    <input type="password" name="password" class="form-control" placeholder="Enter password">
    <span class="help-block text-danger"><?php echo $password; ?></span>
    <p>
    <input type="submit" class="btn btn-primary btn-lg"  name="submit" value="Log IN">
    </p>
    <p> Dont have an account? <a href= "reg.php">Sign up now! </a> </p> 
  </form>

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>



<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>

</body>
</html>

