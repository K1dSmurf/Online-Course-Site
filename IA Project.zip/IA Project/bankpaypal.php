 <?php
session_start();

if(!isset($_SESSION['name'])){
  echo <<<EOF
<script>
  alert("Sorry, you must be logged in to view this.");
window.history.back();
 </script>
EOF;
}
//Function for viewing login name
function loginname(){
if(empty($_SESSION["name"])){
  echo "";
}
else{
  echo "Welcome ".$_SESSION["name"];
}
}

  $Username="";
  //Cookie Creation
  setcookie("Username", $Username, time()+(86400*30),"/");

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->
  <h1> <?php loginname(); ?> </h1>
       <h2>Payment Invoice</h2>
	  <br>
	  <br>
	</div>

 <!-- credit -->
 <div id="net-banking">
                        <div class="form-group "> <label for="Select Your Bank">
                                <h6>Select your Bank</h6>
                            </label> <select class="form-control" id="ccmonth">
                                <option value="" selected disabled>--Please select your Credit card provider<--</option>
                                <option>Visa</option>
                                <option>Mastercard</option>
                                <option>American Express</option>
                                <option>Discover </option>
                                
                            
                            </select> </div>
                       
                    <!-- Paypal info -->
                    <div id="paypal">
                        <h6 class="pb-2">Select your paypal account type</h6>
                        <div class="form-group "> <label class="radio-inline"> <input type="radio" name="optradio" checked> Personal </label> <label class="radio-inline"> <input type="radio" name="optradio" class="ml-5">Business </label></div>
                        <a href="https://www.paypal.com/signin%22%3E <button type="button" class="btn btn-primary "><i class="fab fa-paypal mr-2"></i> Log into my Paypal</button> </a>
                        
                    <!-- bank transfer info -->
                    <div id="net-banking">
                        <div class="form-group "> <label for="Select Your Bank">
                                <h6>Select your Bank</h6>
                            </label> <select class="form-control" id="ccmonth">
                                <option value="" selected disabled>--Please select your Bank--</option>
                                <option>Scotia</option>
                                <option>NCB</option>
                                <option>Sagicor</option>
                                <option>JAMMB </option>
                                <option>JN </option>
                            
                            </select> </div>
                        <div class="form-group">
                        </a><p><b><a href="payment.php" target="button"><button type="button" onclick="alert('Navigating to Payment Page.')">Proceed To Payment</button>
                        </div>
                        
                    <!-- End -->
                </div>
            </div>
        </div>

    

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>


    </div>
<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>

</body>
</html>

 
