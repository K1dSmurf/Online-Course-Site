<?php
session_start();

//Function for viewing login name
function loginname(){
	if(empty($_SESSION["name"])){
		echo "";
	}
	else{
		echo "Welcome ".$_SESSION["name"];
	}
	}
  $id="";
//Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>

<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
      <h1> <?php loginname(); ?> </h1>
	<!--Greeting to user, displays name if they're logged in-->
      <h1>About This Site</h1>
	  <br>
	  <br>
	  <br>
	</div>

<div class="container">
<div class="row">
    <div class="col-sm-12">
	<h2>Here at Mr. Williams Teaching Resources, we believe that knowledge should be shared, not withheld.</h2>
	<br>
	<h2>We are an organization in Mandeville that is dedicated to helping distraught students to find their way through their Computer Science courses. There are multiple guided courses that students can pick from and select, in addition to a variety of resources that will come in handy.</h2>
	<br>
	<h2>We started this business because we know that computer science is one of the most difficult subjects to teach by far, especially in Jamaica. We aim to make the learning process as smooth as possible.</h2>
	<br>
	<h2>If there are any other questions, or if you are a student in need of assistance, we would be more than happy to answer any questions you might have through contact.</h2>
    </div>
  </div>
  <!--Provide another row with pictures of founders.-->
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>
<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>
</body>
</html>
