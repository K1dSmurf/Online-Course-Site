<?php
session_start();
//Function for viewing login name
function loginname(){
  if(empty($_SESSION["name"])){
    echo "";
  }
  else{
    echo "Welcome ".$_SESSION["name"];
  }
  
  }
$output="";
$conn = new mysqli('localhost', 'root', '', 'newdb') or die($conn->connect_error);
$id="";
//Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");

if(isset($_POST['search']))
{
    $select = $_POST['search'];


    $query = mysqli_query($conn,"Select * from courses WHERE c_name like '%$select%' OR c_description like '%$select%'") or die("Could not search");

    $count = mysqli_num_rows($query);
    if($count == 0 || $select == NULL){
        $output = 'There was no match';
    }
    else{
        while($row = mysqli_fetch_array($query))
        {
            $c_name   = $row['c_name'];
            $c_lecturer   = $row['c_lecturer'];
            $c_description   = $row['c_description'];
          

            $output .= "<br/>"."<br/>".
            "<div>".
            "<table>".
            "<tr>"
            ."<th>"."CourseName"."</th>".
            
            "<th>"."CourseLecturer"."</th>".
            "<th>"."Coursedescrption"."</th>".
            "</tr>".
            "<tr>"
            ."<td>".$c_name."</td>".
            "<td>".$c_lecturer."</td>".
            "<td>".$c_description."</td>".
            "</tr>"
            ."</table>"
            ."</div>";
        }
    }


}


?>



<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<title>Welcome | </title>
        <SCRIPT LANGUAGE="JavaScript">
            history.forward()
        </SCRIPT>
</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
    <h1> <?php loginname(); ?> </h1>
<br><br><br>

    <form action ="search.php"  method ="post">
        <input type="text" name="search" placeholder="Search...">
        <input type="submit" value="Search for Courses">
        
        <?php

        echo($output);

        ?>
    </form>

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>



<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>

</body>
</html>
