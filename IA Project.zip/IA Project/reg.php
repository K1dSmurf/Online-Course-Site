<?php

session_start();//strarts session

$fname="";
$lname="";
$email="";
$password="";
$password_confirmation="";
$username="";

extract($_REQUEST);
$file=fopen("register.txt","a");

fwrite($file, "First Name :");
fwrite($file, $fname ."\n");

fwrite($file, "Last Name :");
fwrite($file, $lname ."\n");

fwrite($file, "Email Address :");
fwrite($file, $email ."\n");

fwrite($file, "Preferred Username :");
fwrite($file, $username ."\n");

fwrite($file,"password :");
fwrite($file, $password ."\n");

fwrite($file,"password confirmation :");
fwrite($file, $password_confirmation ."\n");
fclose($file);

$username = "";
$password = "";

$hash= password_hash($password, PASSWORD_DEFAULT);

$passwordlength= strlen($password);

//////////////////////////////////////////////
  $id ="";
  //Cookie Creation
  setcookie("id", $id, time()+(86400*30),"/");
///////////////////////////////////////////
/* Check Login form submitted */
    if(isset($_POST['Submit'])){

      /* Check and assign submitted Username and Password to new variable */
      $username = isset($_POST['username']) ? $_POST['username'] : '';
      $password = isset($_POST['password']) ? $_POST['password'] : '';
      
      /////////////////////
      if (empty($_POST["username"])){

        $username = "*Please enter username";
    }
    if (empty($_POST["password"])){

      $password = "*Please enter password";
  }
     if (empty($_POST["email"])){

    $email = "*Please enter email";
}

      /* Check Username and Password existence in defined array */
      if (strlen($password)>7 && strlen($username)>0){
      /* Success: Set session variables and redirect to Protected page  */
        $_SESSION['username']=$username;
        $_SESSION['password']=$password;
        header("RegistrationData.php");
       
      } else {
      /*Unsuccessful attempt: Set error message */
      $msg="<span style='color:red'>Invalid Login. Please ensure that the fields are not empty and that the password is 8 characters or more.</span>";
      }
      }
  //Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>



<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->
      <h1>Register!</h1>

	  <br>
	  <br>

	</div>

<br><br><br>
  <form method="POST" action="RegistrationData.php" method="post">>
    <?php if(isset($msg)){?>
    <tr height=10px >
      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="2" align="left" valign="top"></td>
    </tr>
    <tr>
      <td align="right" valign="top"><strong>Username </strong></td>
      <td><input name="Username" type="text" class="Input"></td>
      <span class="help-block text-danger"><?php echo $username; ?></span>
    </tr>
    <tr>
      <td align="right" valign="top"><strong>First Name: </strong></td>
      <td><input name="fname" type="text" class="Input"></td>
    </tr>
    <tr>
      <td align="right" valign="top"><strong>Last Name: </strong></td>
      <td><input name="lname" type="text" class="Input"></td>
    </tr>
    <tr>
      <td align="right"><strong>Password:</strong></td>
      <td><input name="Password" type="password" class="Input"></td>
    </tr>
    <tr>
      <td align="right"><strong>Confirm Password:</strong></td>
      <td><input name="password_confirmation" type="password" class="Input"></td>
    </tr>
    <tr>
      <td align="right"><strong>Email:</strong></td>
      <td><input name="email" type="text" class="Input"></td>
    </tr>
    <tr>
      <td> </td>
      <td><input name="Submit" type="submit" value="Login" class="Button3"></td>
    </tr>
  </table>
</form>

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>



<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>

</body>
</html>
