<?php

require 'connect.php';

$fname="";
$lname="";
$email="";
$Password="";
$password_confirmation="";
$Username="";
$subject="";
$msg="";


//Cookie Creation
setcookie("fname", $fname, time()+(86400*30),"/");

$conn    = Connect();
$fname   = $conn->real_escape_string($_POST['fname']);
$lname   = $conn->real_escape_string($_POST['lname']);
$email   = $conn->real_escape_string($_POST['email']);
$Password   = $conn->real_escape_string($_POST['Password']);
$password_confirmation   = $conn->real_escape_string($_POST['password_confirmation']);
$Username   = $conn->real_escape_string($_POST['Username']);

$query   = "INSERT into users (	fname,lname,email,password,password_confirmation,username ) VALUES ('" . $fname . "','" . $lname . "','" . $email . "','" . $Password . "','" . $password_confirmation . "','" . $Username . "')";
$success = $conn->query($query);

if (!$success) {
    die("Couldn't enter data: ".$conn->error);

}

///////
if(isset($_POST['Submit'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $Password = $_POST['Password'];
    $Username = $_POST['Username'];
    $subject = "Welcome";
    $msg = "hello you have registered";
    // Content-Type helps email client to parse file as HTML 
    // therefore retaining styles
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $message = "<html>
    <head>
        <title>New message from website contact form</title>
    </head>
    <body>
        <h1>" . $subject . "</h1>
        <p>".$msg."</p>
    </body>
    </html>";
    if (mail($email, $subject, $message, $headers)) {
     echo "Email sentz";
    }else{
     echo "Failed to send email. Please try again later";
    }
  }
////
  

$conn->close();

?>

<!Doctype html>
<html lang="en" >
<head> 
  <meta charset="UTF-8">
  <title>Williams Online Teaching Resources</title>
   <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/Buttonstyle.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script> 
</head>

<body>

    <br><br><br><br><br><br><br><br><br><br><br><br>
    <center><h1><?php echo "Thank you for Registering" ?></h1><center>
    <button class="button button1"> <a href="login.php">CLICK HERE TO GO BACK TO BACK TO LOG IN</a></button><br>
    <br>
       

    
</body>

</html>