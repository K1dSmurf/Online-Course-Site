<?php
session_start();
if(!isset($_SESSION['name'])){
  echo <<<EOF
<script>
  alert("Sorry, you must be logged in to view this.");
window.history.back();
 </script>
EOF;
}
//Function for viewing login name
function loginname(){
if(empty($_SESSION["name"])){
  echo "";
}
else{
  echo "Welcome ".$_SESSION["name"];
}

}
	//connects to the connection file 
    require 'connect2.php';

    $conn    = Connect2();
	//control statement
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $c_name = $_POST['c_name'];
        $c_lecturer = $_POST['c_lecturer'];
        $c_description = $_POST['c_description'];
        

	mysqli_query($conn, "UPDATE courses SET c_name='$c_name', c_lecturer='$c_lecturer', c_description='$c_description' WHERE id=$id");
	 
	header('location: successful.php');
  //Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->

	</div>

<form action="" method="post">


<h1> <?php loginname(); ?> </h1>
<center><h1>Enter the information on your recipt<h1><center>

      ID:<br>
        <input type="text" name="id" required><br>
        
	  Course Name:<br>
		<input type="text" name="c_name" required><br>

        Lecturer Name:<br>
		<input type="text" name="c_lecturer" required><br>
	  
	  Description:<br>
		<input type="text" name="c_description" required><br>
	  
	  

	  
		<input type="submit" name="update" value="Update">
		
	</form>

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>



<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>

</body>
</html>

