<?php 
session_start();
if(!isset($_SESSION['name'])){
    echo <<<EOF
  <script>
    alert("Sorry, you must be logged in to view this.");
  window.history.back();
   </script>
EOF;
}
//Function for viewing login name
function loginname(){
	if(empty($_SESSION["name"])){
		echo "";
	}
	else{
		echo "Welcome ".$_SESSION["name"];
	}
	}
$id="";
//Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="css/styles.css">
<style>
  .container{
    
    
    align-items:center;
  }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Williams Online Teaching Resources - Courses</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Return to Home Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="reg.php">Sign Up</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Log Out</a>
        </li>

      </ul>
    </div>
  </div>

</nav>

<div class="graphic-container">

    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
    <h1> <?php loginname(); ?> </h1>
<br><br><br>
<div class="container">
  <form action="Online Courses.php" method="POST">
<div class="card-group" style="width:70rem;">
  <div class="card">
    <img src="img/IA.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Internet Authoring</h5>
      <p class="card-text"></p>
      
      <div>
      <input onclick="change()" type="button" value="Subscribe" id="myButton1"></input>
    
  </div>
  <script src="js/script.js"></script>
</div>
</div>
  <div class="card">
  <img src="img/web.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Web Design & Implementation</h5>
      <p class="card-text"></p>
      
      <div>
      <input onclick="change1()" type="button" value="Subscribe" id="myButton2"></input>
    
  </div>
  <script src="js/script.js"></script>
      
    </div>
  </div>
  <div class="card">
  <img src="img/OS.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title"> Operating Systems</h5>
      <p class="card-text"></p>
      <div>
      <input onclick="change2()" type="button" value="Subscribe" id="myButton3"></input>
    
  </div>
  <script src="js/script.js"></script>
    
    </div>
  </div>
</div>



<div class="card-group" style="width:70rem;">
  <div class="card">
  <img src="img/DS.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Database Systems </h5>
      <p class="card-text"></p>
      
      <div>
      <input onclick="change3()" type="button" value="Subscribe" id="myButton4"></input>
    
  </div>
  <script src="js/script.js"></script>
    
    </div>
  </div>
  <div class="card">
  <img src="img/DT.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Data Telecommunication</h5>
      <p class="card-text"></p>

      <div>
      <input onclick="change4()" type="button" value="Subscribe" id="myButton5"></input>
    
  </div>
  <script src="js/script.js"></script>
    
    </div>
  </div>
  <div class="card">
  <img src="img/DSS.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Data Security</h5>
      <p class="card-text"></p>
      
      <div>
      <input onclick="change5()" type="button" value="Subscribe" id="myButton6"></input>
    
  </div>
  <script src="js/script.js"></script>
    
    </div>
  </div>
</div>

</div>







</div>

<div class="container">
  <div class="row">
  </div>
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>

<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>
</body>
</html>