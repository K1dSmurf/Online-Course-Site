<?php
session_start();

if(!isset($_SESSION['name'])){
  echo <<<EOF
<script>
  alert("Sorry, you must be logged in to view this.");
window.history.back();
 </script>
EOF;
}
//Function for viewing login name
function loginname(){
if(empty($_SESSION["name"])){
  echo "";
}
else{
  echo "Welcome ".$_SESSION["name"];
}
}
$Username="";
//Cookie Creation
setcookie("Username", $Username, time()+(86400*30),"/");

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->
  <h1> <?php loginname(); ?> </h1>
      <h1>Payment Invoice</h1>
	  <br>
	  <img class="mygif" src="https://media0.giphy.com/media/Wvga3U9ur6dwc/giphy.gif?cid=ecf05e47muo6y5p0fhxb5q63kdpib0f66xsep9g7yvpa5ay4&rid=giphy.gif&ct=g" alt="creditcard">
<br>
	  <br>
	  <br>
	</div>
 

            <div class="card ">
                <div class="card-header">
                        <!-- Credit card form tabs -->
                        <ul role="tablist">
                            <a href="#credit-card"> Credit Card </a>
                            <a href="https://www.paypal.com/signin" target="_blank">  Paypal </a>
                            <a href="https://www.online.scotiabank.com/onlineV1/leap/signon/signOn.xhtml?country=JAM&lang=en&channel=WEB" target="_blank"> Bank Transfer </a>
                            </div>
							</div>





<img src="https://w7.pngwing.com/pngs/1016/14/png-transparent-logo-american-express-credit-card-mastercard-visa-credit-card-text-logo-payment.png" alt="Paris" width="100" height="100">







<img src="https://pbs.twimg.com/profile_images/1440303464391737346/cLVCdOYu_400x400.png" alt="Paris" width="100" height="100">






<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoLzxiuqIdj6r13s9yi9ktlVfnMutFFz9D5e8mG8net3mnMOkpZRlU6UsgYAHQqqMGp7U&usqp=CAU" alt="Paris" width="100" height="100">

  
                        <div>
                            <form role="form" onsubmit="event.preventDefault()">
                                <div class="form-group"> <label for="username">
								<br><br><br>
                                        <h6>Card Owner</h6>
                                    </label> <input type="text" name="username" placeholder="Card Owner Name" required class="form-control"> </div>
                                <div class="form-group"> <label for="cardNumber">
                                        <h6>Card number</h6>
                                    </label>
                                    <div class="input-group"> <input type="text" name="cardNumber" placeholder="Valid card number" class="form-control">
                                        <div class="input-group-append"> <span class="input-group-text text-muted"> <i class="fab fa-cc-visa mx-1"></i> <i class="fab fa-cc-mastercard mx-1"></i> <i class="fab fa-cc-amex mx-1"></i> </span> </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="form-group"> <label><span class="hidden-xs">
                                                    <h6>Expiration Date</h6>
                                                </span></label>
                                            <div> <input type="number" placeholder="MM" name="" class="form-control" required> <input type="number" placeholder="YY" name="" class="form-control" required> </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mb-4"> <label data-toggle="tooltip" title="Three digit CV code on the back of your card">
                                                <h6>CVV <i class="fa fa-question-circle d-inline"></i></h6>
                                            </label> <input type="text" required class="form-control"> </div>
                                    </div>
                                </div>
                                </a><p><b><a href="payment.php" target="button"><button type="button" onclick="alert('Your Payment was Successfully Processed.')">Confirm Payment</button>
                            </form>
                        </div>
<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
						
</div>


</body>
</html>




