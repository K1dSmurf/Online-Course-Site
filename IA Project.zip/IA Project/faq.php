<?php
session_start();

//Function for viewing login name
function loginname(){
	if(empty($_SESSION["name"])){
		echo "";
	}
	else{
		echo "Welcome ".$_SESSION["name"];
	}
	}
$id="";
//Cookie Creation
setcookie("id", $id, time()+(86400*30),"/");
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Williams Online Teaching Resources</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-dark bg-success">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Williams Online Teaching Resources
  </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="Online Courses.php">Courses</a></li>
	  <li><a href="faq.php">FAQ</a></li>
	  	  <li><a href="bankpaypal.php">Credit Information</a></li>
		  	  <li><a href="payment.php">Payment</a></li>
			  			  <li><a href="update.php">Update Courses</a></li>
			  <li><a href="delete.php">Delete Courses</a></li>
			  			  <li><a href="search.php">Search Courses</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="reg.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
	</ul>
  </div>
</nav>
<div class="graphic-container">
    <img class="top-cloud" src="images/cloud.png" alt="cloud">
    <div class="title-text">
	<!--Greeting to user, displays name if they're logged in-->
       <h1> <?php loginname(); ?> </h1>
      <h1>Frequently Asked Questions</h1>
	  <br>
	  <img class="mygif" src="https://media2.giphy.com/media/xiE902jeKqe4libpvF/giphy.gif?cid=ecf05e47arumif1si61nt5k3htbefle6zpzdl61ysanyzwoa&rid=giphy.gif&ct=g" alt="bookopen">
      <h2>Check out any questions here that are often asked.<br>There are more queries on our social media, so check it out!</h2>
	  <br>
	  <br>
	</div>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>How long does it take to get a reply?</h3>
      <p>Replies are usually processed withing 3-5 business days.</p>
      <p>Please be patient with us!</p>
    </div>
    <div class="col-sm-4">
      <h3>I can't see available courses. Why is that?</h3>
	  <p>You are either not subscribed, or there may be an issue with the system. </p>
      <p>If there is an error, please do not hesitate to contact us.</p>
    </div>
    <div class="col-sm-4">
      <h3>Where can I learn more about updates to the courses?</h3>        
      <p>Visit the other websites below, where you can see our social media for updates that are to be announced.</p>
      <p>You can also see questions from other subscribers to see if a question of yours has already been answered.</p>
    </div>
  </div>
  
    <div class="row">
    <div class="col-sm-4">
      <h3>Can I provide extra notes and tutorials to the site?</h3>
      <p>Sure you can! Simply contact through the contact form and we'll get back to you if we think your idea for notes/tutorials is valuable!</p>
      <p>Just make sure that it is related to Computer Science, we are not accepting tutorials for other topics at the moment.</p>
    </div>
    <div class="col-sm-4">
      <h3>What kind of Computer Science tutorials are covered in this site?</h3>
	  <p>Any computer science topics that have been covered by Mr. Williams are shown in this site, such as Website Design and Internet Authoring.</p>
      <p>If you are interested, you can view them in the navbar above!</p>
    </div>
    <div class="col-sm-4">
      <h3>How do we subscribe?</h3>        
      <p>Simply register in the navbar above, and your information will be registered.</p>
      <p>After you register with a subscriber's account, you can login at any time.</p>
    </div>
  </div>
  
  <img class="mountain" src="images/mountain.png" alt="mountain-img">
</div>
<div class="bottom-container">
  <a class="footer-link" href="#">LinkedIn</a>
  <a class="footer-link" href="#">Twitter</a>
  <a class="footer-link" href="#">Website</a>
  <p class="copyright">© 2022 Williams Gang @ Teaching Resources.</p>
</div>
</div>
</body>
</html>
